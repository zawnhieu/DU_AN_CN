
@extends('layout.main')
@section('content')

<h3 style="text-align: center;">Đăng nhập</h3>
<form action="{{ route('login') }}" method="POST">
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" value="">
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Mật khẩu</label>
        <input type="password" class="form-control" id="password" name="password">
    </div>
    <div class="d-grid">
        <button type="submit" class="btn btn-primary" name="login">Đăng nhập</button>
    </div>
</form>

@endsection
