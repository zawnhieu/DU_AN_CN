@extends('layout.main')

@section('content')
<div class="container mt-4">
    @if(isset($_SESSION['errors']) && isset($_GET['msg']))
    <div class="alert alert-danger">
        <ul>
            @foreach($_SESSION['errors'] as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    @if(isset($_SESSION['success']) && isset($_GET['msg']))
    <div class="alert alert-success">
        {{ $_SESSION['success'] }}
    </div>
    @endif
    <h3 style="text-align: center;">Thêm Ghi Chú Của Bạn</h3>
    <form action="{{ route('post-ghichu') }}" method="POST">
        @csrf
        @php
        $currentDate = date('Y-m-d');
        $currentTime = date('H:i');
        @endphp
        <div class="mb-3">
            <label for="title" class="form-label">Tiêu đề</label>
            <input type="text" class="form-control" id="title" name="title" value="">
        </div>
        <div class="mb-3">
            <label for="text" class="form-label">Nội dung</label>
            <input type="text" class="form-control" id="text" name="text" value="">
        </div>
        <div class="mb-3">
            <label for="date" class="form-label">Ngày thông báo</label>
            <input type="date" class="form-control" id="date" name="date" value="{{ $currentDate }}">
        </div>
        <div class="mb-3">
            <label for="time" class="form-label">Giờ thông báo</label>
            <input type="time" class="form-control" id="time" name="time" value="{{ $currentTime }}">
        </div>
        <!-- <div class="mb-3">
            <label for="date_noti" class="form-label">Ngày thông báo</label>
            <input type="date" class="form-control" id="date_noti" name="date_noti" value="">
        </div>
        <div class="mb-3">
            <label for="time_noti" class="form-label">Giờ thông báo</label>
            <input type="time" class="form-control" id="time_noti" name="time_noti" value="">
        </div> -->
        <input type="hidden" name="id_user" value="{{ $_SESSION['user']->id }}">
        <div class="d-grid">
            <button type="submit" class="btn btn-primary" name="add">Thêm</button>
        </div>
    </form>
</div>
@endsection