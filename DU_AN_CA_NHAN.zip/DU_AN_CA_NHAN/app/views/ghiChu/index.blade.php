@extends('layout.main')
@section('content')
<div class="container">
    <h1 class="my-4">{{ $header }}</h1>
    @if(isset($_SESSION['errors']) && isset($_GET['msg']))
    <div class="alert alert-danger">
        <ul>
            @foreach($_SESSION['errors'] as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    @if(isset($_SESSION['success']) && isset($_GET['msg']))
    <div class="alert alert-success">
        {{ $_SESSION['success'] }}
    </div>
    @endif
    <a href="{{ route('add-ghichu/') }}" class="btn btn-primary mb-3">Thêm ghi chú</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tiêu đề</th>
                <th>Nội dung</th>
                <th>Thời gian thông báo</th>
                <!-- <th>Ngày thông báo</th> -->
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            @foreach($ghiChu as $pr)
            <tr>
                <td>{{ $pr->title }}</td>
                <td>{{ $pr->text }}</td>
                <td>{{ $pr->date }}</td>
                <!-- <td>{{ $pr->time_noti }}</td> -->

                <td>
                    <a href="{{ route('detail-product/'.$pr->id) }}" class="btn btn-warning btn-sm">Sửa</a>
                    <a href="{{ route('delete-ghichu/'.$pr->id) }}" class="btn btn-danger btn-sm">Xóa</a>
                    <!-- <a href="{{ route('delete-product/'.$pr->id) }}" class="btn btn-success btn-sm">Đặt thông báo</a> -->

                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection