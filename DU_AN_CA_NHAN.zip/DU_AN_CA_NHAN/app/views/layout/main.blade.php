<!doctype html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('layout.style')
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Quản lý ghi chú</title>
    <style>
        body {
            background-color: #f0f8ff;
            /* Light cyan background */
        }

        .navbar {
            background-color: #6cd979;
            /* Dark brown background for navbar */
            color: black;
        }

        .navbar a {
            color: black;
        }

        .footer {
            background-color: #6cd979;
            color: black;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <header class="mb-4">
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-brand" href="#">Quản Lý Ghi Chú</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <i class="fa-regular fa-note-sticky"><a class="nav-link" href="list-ghichu">Ghi chú của bạn</a>
                            </i>

                        </li>
                    </ul>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            @if(isset($_SESSION['user']))
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Người dùng: {{ $_SESSION['user']->id }}
                            </a>
                            @else
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Người dùng: Khách
                            </a>
                            @endif
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                                @if(isset($_SESSION['user']))
                                <a class="dropdown-item" href="logout">Đăng xuất</a>
                                @else
                                <a class="dropdown-item" href="login">Đăng nhập</a>
                                @endif
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <section class="content">
            @yield('content')
        </section>
        <footer class="footer text-center mt-4">
            <span>&copy; 2024 ZawnHieu</span>
        </footer>
    </div>
    <!-- Bootstrap JS và các thư viện phụ thuộc -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>