<?php

namespace App\Models;

class GetData extends BaseModel
{
    protected $table = "text";


    public function _getdata()
    {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        //echo date('Y-m-d H:i:s');
        $sql = "SELECT * FROM $this->table where isPush = 'chuathongbao'";
        $this->setQuery($sql);
        $user = $this->loadAllRows([]);
        $mangx = [];
        foreach ($user as $index => $key) {
            if (strtotime(date('Y-m-d H:i:s')) > strtotime($key->date)) {
                array_push($mangx, $key);
            }
        }
        die(json_encode($mangx, JSON_PRETTY_PRINT));
    }
}
