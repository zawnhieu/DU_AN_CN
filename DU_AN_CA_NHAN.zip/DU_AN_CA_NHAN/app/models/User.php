<?php

namespace App\Models;

class User extends BaseModel
{
    protected $table = "user";

    // Hàm kiểm tra thông tin đăng nhập
    public function checkLogin($email, $password)
    {
        $sql = "SELECT * FROM $this->table WHERE email=? AND password=?";
        $this->setQuery($sql);
        $user = $this->loadRow([$email, $password]);

        // Kiểm tra xem dữ liệu có tồn tại không
        if ($user) {
            return $user;
        } else {
            return null; // hoặc return false; tùy thuộc vào cách bạn muốn xử lý
        }
    }
}
