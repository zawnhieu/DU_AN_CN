<?php

namespace App\Models;

class GhiChu extends BaseModel
{
    protected $table = "text";
    // lấy danh sách sản phẩm
    public function getGhiChu($userId)
    {
        $sql = "SELECT * FROM $this->table WHERE id_user = ?";
        $this->setQuery($sql);
        return $this->loadAllRows([$userId]);
    }
    public function addGhiChu($id, $title, $text, $date, $user_send, $isPush,  $id_user)
    {
        $sql = "INSERT INTO $this->table VALUES (?, ?, ?, ?, ?, ?, ?) ";
        $this->setQuery($sql);
        return $this->execute([$id, $title, $text, $date, $user_send, $isPush, $id_user]);
    }

    public function deleteGhiChu($id)
    {
        $sql = "delete from $this->table where id=?";
        $this->setQuery($sql);
        return $this->execute([$id]);
    }

    public function updateStatus($id)
    {
        $sql = "UPDATE $this->table SET isPush = 'dathongbao' WHERE id = ?";
        $this->setQuery($sql);
        return $this->execute([$id]);
    }
}
