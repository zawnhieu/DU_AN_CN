<?php

namespace App\Controllers;

use App\Models\GhiChu;


class GhiChuController extends BaseController
{
    public $ghiChu;

    public function __construct()
    {
        $this->ghiChu = new GhiChu();
    }

    // Trong GhiChuController
    public function index()
    {
        // Kiểm tra xem biến người dùng đã được thiết lập chưa
        if (isset($_SESSION['user'])) {
            // Lấy ID của người dùng đăng nhập từ session
            $userId = $_SESSION['user']->id;

            // Lấy danh sách ghi chú của người dùng hiện tại
            $ghiChuModel = new GhiChu();
            $ghiChu = $ghiChuModel->getGhiChu($userId);

            return $this->render('ghiChu.index', compact('ghiChu'));
        } else {
            // Xử lý trường hợp không có người dùng đăng nhập
            // Ví dụ: chuyển hướng người dùng đến trang đăng nhập
            header('Location: ' . BASE_URL . 'login');
            exit;
        }
    }


    public function addGhiChu()
    {

        return $this->render('ghiChu.add');
    }
    public function postGhiChu()
    {
        if (isset($_POST['add'])) {
            $errors = [];
            // tạo mảng lỗi = rỗng
            if (empty($_POST['title'])) {
                $errors[] = "Tiêu đề không được để trống";
            }

            if (empty($_POST['text'])) {
                $errors[] = "Nội dung không được để trống";
            }
            if (empty($_POST['date'])) {
                $errors[] = "Ngày thêm không được để trống";
            }

            if (empty($_POST['id_user'])) {
                $errors[] = "id không được để trống";
            }

            if (count($errors) > 0) {
                // =>có lỗi
                flash('errors', $errors, 'add-ghichu');
            } else {
                $datetime = $_POST['date'] . " " . $_POST['time'];
                // $datetime_noti = $_POST['date_noti'] . " | " . $_POST['time_noti'];

                $result = $this->ghiChu->addGhiChu(NULL, $_POST['title'], $_POST['text'], $datetime, $_SESSION['user']->email,  'chuathongbao', $_POST['id_user']);
                if ($result) {
                    flash('success', "Thêm mới thành công", 'list-ghichu');
                }
            }
        }
    }
    public function updateStatus()
    {
        if (!empty($_GET['id'])) { // empty
            $id = $_GET['id'];
            if (!is_numeric($id)) {
                die(json_encode(['status' => false, 'message' => 'ID phải là số']));
            }
            if ($id == '') {
                die(json_encode(['status' => false, 'message' => 'Trường ID không được để trống']));
            }
            $result = $this->ghiChu->updateStatus($id);
            if ($result) {
                echo json_encode(['status' => true, 'message' => 'Cập nhật trạng thái thành công']);
            } else {
                echo json_encode(['status' => false, 'message' => 'Cập nhật trạng thái thất bại']);
            }
        } else {
            echo json_encode(['status' => false, 'message' => 'ID không được cung cấp']);
        }
    }
    // public function detail($id){

    //     $product = $this->product->getDetailProduct($id);
    //     return $this->render('product.edit',compact('product', 'categories'));
    // }

    // public function editProduct($id){
    //     if(isset($_POST['edit'])){
    //         $result = $this->product->updateProduct($id,$_POST['name'],$_POST['price'],$_POST['id_categories']);
    //         if($result){
    //             flash('success',"Sửa thành công",'list-product/');
    //         }
    //     }
    // }

    // xóa sản phẩm
    public function deleteGhiChu($id)
    {
        $result = $this->ghiChu->deleteGhiChu($id);
        if ($result) {
            flash('success', "Xóa thành công", 'list-ghichu');
        }
    }
}
