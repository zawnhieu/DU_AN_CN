<?php

namespace App\Controllers;

use App\Models\User;
use App\Helpers\SessionHelper;

class UserController extends BaseController
{
    public $user;

    public function __construct()
    {
        $this->user = new User();
    }

    // Hàm hiển thị trang đăng nhập
    public function showLoginForm()
    {
        return $this->render('ghiChu.login');
    }

    // Hàm xử lý đăng nhập
    public function login()
    {
        if (isset($_POST['login'])) {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $user = $this->user->checkLogin($email, $password);

            if ($user) {
                // Đăng nhập thành công, lưu thông tin người dùng vào session
                SessionHelper::set('user', $user);

                // Chuyển hướng người dùng sau khi đăng nhập thành công
                header('Location: ' . BASE_URL . 'list-ghichu');
                exit;
            } else {
                echo "<script>alert('Tên đăng nhập hoặc mật khẩu không đúng');</script>";
            }
        }
    }


    //Hàm đăng xuất
    public function logout()
    {
        // Xóa thông tin người dùng khỏi session khi đăng xuất
        SessionHelper::remove('user');
        header('Location: ' . BASE_URL . 'list-ghichu');

        // Redirect hoặc hiển thị thông báo đăng xuất thành công
    }

    // Các phương thức khác có thể được thêm vào ở đây
}
