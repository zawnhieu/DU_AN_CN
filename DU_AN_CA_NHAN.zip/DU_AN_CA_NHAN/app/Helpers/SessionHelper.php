<?php

namespace App\Helpers;

class SessionHelper
{
    public static function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }

    public static function get($key)
    {
        return $_SESSION[$key] ?? null;
    }

    public static function remove($key)
    {
        unset($_SESSION[$key]);
    }

    // Các phương thức khác có thể được thêm vào ở đây
}
