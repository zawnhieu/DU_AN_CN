<?php

use Phroute\Phroute\RouteCollector;

$url = !isset($_GET['url']) ? "/" : $_GET['url'];

$router = new RouteCollector();

// filter check đăng nhập
$router->filter('auth', function () {
    if (!isset($_SESSION['auth']) || empty($_SESSION['auth'])) {
        header('location: ' . BASE_URL . 'login');
        die;
    }
});

// khu vực cần quan tâm -----------
// bắt đầu định nghĩa ra các đường dẫn
$router->get('/', function () {
    return "trang chủ";
});
//định nghĩa đường dẫn trỏ đến Product Controller
$router->get('list-ghichu', [App\Controllers\GhiChuController::class, 'index']);
$router->get('add-ghichu', [App\Controllers\GhiChuController::class, 'addGhiChu']);
$router->post('post-ghichu', [App\Controllers\GhiChuController::class, 'postGhiChu']);
$router->get('test', [App\Controllers\GetccController::class, 'index']);
// $router->get('detail-product/{id}',[App\Controllers\GhiChuController::class,'detail']);
// $router->post('edit-product/{id}',[App\Controllers\GhiChuController::class,'editProduct']);
$router->get('delete-ghichu/{id}', [App\Controllers\GhiChuController::class, 'deleteGhiChu']);


$router->get('update-status', [App\Controllers\GhiChuController::class, 'updateStatus']);





//login + logout
$router->get('login', [App\Controllers\UserController::class, 'showLoginForm']);
$router->post('login', [App\Controllers\UserController::class, 'login']);
$router->get('logout', [App\Controllers\UserController::class, 'logout']);

$router->filter('auth', function () {
    if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
        header('location: ' . BASE_URL . 'login');
        die;
    }
});
$router->group(['before' => 'auth'], function ($router) {
    // Đặt tất cả các đường dẫn mà bạn muốn bảo vệ ở đây
});





//$router->get('test', [App\Controllers\ProductController::class, 'index']);

# NB. You can cache the return value from $router->getData() so you don't have to create the routes each request - massive speed gains
$dispatcher = new Phroute\Phroute\Dispatcher($router->getData());

$response = $dispatcher->dispatch($_SERVER['REQUEST_METHOD'], $url);

// Print out the value returned from the dispatched function
echo $response;
